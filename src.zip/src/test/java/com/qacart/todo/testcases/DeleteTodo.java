package com.qacart.todo.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class DeleteTodo {

    WebDriver driver = new ChromeDriver();

    @Test(priority = 1)
    public void todoShouldBeDeleted() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        driver.get("https://qacart-todo.herokuapp.com/login");

        String email = "mohannad.alaydi@gmail.com";
        String password = "0786325m";
        String[] todoText = {"Unit Test", "Integration Test", "System Test", "UAT Test"};
        driver.manage().window().maximize();

        // Login
        driver.findElement(By.cssSelector("[data-testid='email']")).sendKeys(email);
        driver.findElement(By.cssSelector("[data-testid='password']")).sendKeys(password);
        driver.findElement(By.cssSelector("[data-testid='submit']")).click();

        // Wait for dashboard to load
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

        List<WebElement> taskElements = driver.findElements(By.cssSelector("[data-testid=\"delete\"]"));

        // Delete todos
        for (int i=0;i<taskElements.size();i++) {
            List<WebElement> deleteButtons = driver.findElements(By.cssSelector("[data-testid=\"delete\"]"));

            deleteButtons.get(0).click();
            Thread.sleep(300);
            if(i==taskElements.size()-1){
                System.out.println("Number of Item Deleted : "+todoText.length);}

        }

        List<WebElement> remainingTasks = driver.findElements(By.cssSelector("[data-testid='delete']"));
        Assert.assertEquals(remainingTasks.size(), 0, "All tasks should be deleted");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        driver.quit();
    }
}
