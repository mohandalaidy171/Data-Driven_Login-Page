package com.qacart.todo.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.Duration;

public class LoginTest {

    @DataProvider(name = "loginData")
    public Object[][] loginDataProvider() throws IOException {
        String filePath = System.getProperty("user.dir") + "/src/test/resources/loginData.xlsx";
        return ExcelUtils.getLoginData(filePath, "Sheet1");
    }

    @Test(dataProvider = "loginData")
    public void ShouldBeAbleToLoginWithValidEmailAndPassword(String email, String password) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://qacart-todo.herokuapp.com/login");

        driver.findElement(By.cssSelector("[data-testid=\"email\"]")).sendKeys(email);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));

        driver.findElement(By.cssSelector("[data-testid=\"password\"]")).sendKeys(password);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));

        driver.findElement(By.cssSelector("[data-testid=\"submit\"]")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));

        WebElement actual = driver.findElement(By.cssSelector("[data-testid=\"welcome\"]"));
        Assert.assertTrue(actual.isDisplayed());
        System.out.println("Logged in with: " + email);

        driver.quit();
    }
}
