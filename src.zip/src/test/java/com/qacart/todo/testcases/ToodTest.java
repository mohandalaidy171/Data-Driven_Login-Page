package com.qacart.todo.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class ToodTest {
    WebDriver driver = new ChromeDriver();

    @Test(priority = 1)
    public void ShouldBeAbleToAddTodo() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://qacart-todo.herokuapp.com/login");

        String email = "mohannad.alaydi@gmail.com";
        String password = "0786325m";
        String[] todoText = {"Unit Test", "Integration Test", "System Test", "UAT Test"};
        driver.manage().window().maximize();
        // Login
        driver.findElement(By.cssSelector("[data-testid='email']")).sendKeys(email);
        driver.findElement(By.cssSelector("[data-testid='password']")).sendKeys(password);
        driver.findElement(By.cssSelector("[data-testid='submit']")).click();

        // Wait for dashboard to load
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("MuiIconButton-root")));

        // Add todos
        for (String task : todoText) {
            driver.findElement(By.className("MuiIconButton-root")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-testid='new-todo']")));
            driver.findElement(By.cssSelector("[data-testid='new-todo']")).sendKeys(task);
            driver.findElement(By.cssSelector("[data-testid='submit-newTask']")).click();
        }

        // Validate todos
        List<WebElement> taskElements = driver.findElements(By.cssSelector("[data-testid='todo-item']"));
        Assert.assertEquals(taskElements.size(), todoText.length);

        for (int i = 0; i < todoText.length; i++) {
            String actualText = taskElements.get(i).getText().trim();
            String expectedText = todoText[todoText.length - 1 - i]; // reverse the index
            Assert.assertEquals(actualText, expectedText, "Mismatch at task index " + i);
            if(i==todoText.length-1){
                System.out.println("Number of Item Added : "+todoText.length);}
        }

        driver.quit();
    }
}
